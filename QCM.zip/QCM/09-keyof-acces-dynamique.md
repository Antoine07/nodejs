# QCM — 09 `keyof` et accès dynamique

## 1) `keyof User` produit…

A. Le type des valeurs de `User`  
B. Une union des clés de `User`  
C. Un tableau de clés au runtime  
D. Une connexion DB

Réponse : **B**  
Explication : `keyof` produit une union de clés (ex: `"id" | "name" | "email"`).

---

## 2) Pourquoi `get(obj, key: string)` n’est pas “safe” ?

A. Parce que `string` peut être n’importe quelle clé (même inexistante)  
B. Parce que `key` est toujours `never`  
C. Parce que `obj` devient `any` automatiquement  
D. Parce que `key` devient `symbol`

Réponse : **A**  
Explication : il faut restreindre `key` à `keyof T` pour garantir une clé valide.

---

## 3) `function get<T, K extends keyof T>(obj: T, key: K): T[K]` garantit que…

A. `key` est une clé valide de `obj`  
B. `obj` est forcément un tableau  
C. `T[K]` est toujours `string`  
D. `K` existe au runtime

Réponse : **A**  
Explication : `key` est valide et le retour est le type exact `T[K]`.

---

## 4) Avec un dictionnaire `Record<string, number>`, `keyof` vaut souvent…

A. `"a" | "b" | "c"`  
B. `string`  
C. `never`  
D. `number`

Réponse : **B**  
Explication : les clés ne sont pas finies, donc `keyof` est `string`.
