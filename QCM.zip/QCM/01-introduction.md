# QCM — 01 Introduction : pourquoi TypeScript ?

## 1) TypeScript sert principalement à…

A. Exécuter du code plus vite au runtime  
B. Détecter des erreurs avant l’exécution via une analyse statique  
C. Remplacer les tests unitaires  
D. Valider automatiquement toutes les réponses API

Réponse : **B**  
Explication : TypeScript fait du **type-check** (compile-time), pas de validation runtime automatique.

---

## 2) “Les types n’existent pas au runtime” signifie que…

A. Les types sont évalués par Node à chaque requête HTTP  
B. Les types sont supprimés et n’affectent pas l’exécution JavaScript  
C. Les types empêchent les exceptions  
D. `JSON.parse` retourne toujours un type sûr

Réponse : **B**  
Explication : les types sont une information pour le compilateur/IDE, pas pour l’exécution.

---

## 3) Quel cas TypeScript ne résout pas “tout seul” ?

A. Une propriété manquante sur un objet interne bien typé  
B. Une donnée API incorrecte si elle n’est pas validée au runtime  
C. Un appel de fonction avec mauvais types en paramètres  
D. Un switch non exhaustif sur une union discriminée

Réponse : **B**  
Explication : les données externes doivent être parsées/validées au runtime (guards, zod, etc.).

---

## 4) La “frontière du système” correspond à…

A. Une règle de nommage des fichiers TypeScript  
B. L’endroit où le code rencontre des entrées externes (HTTP, DB, fichiers, env, JSON)  
C. Une optimisation V8  
D. Un pattern React

Réponse : **B**  
Explication : c’est l’endroit des entrées externes : `unknown`, validation, mapping DTO → Domain, etc.
