# QCM — 10 Node.js (introduction)

## 1) Node.js est…

A. Un framework HTTP  
B. Un runtime JavaScript hors navigateur  
C. Un compilateur TypeScript  
D. Une base de données

Réponse : **B**  
Explication : Node exécute du JavaScript (V8 + APIs).

---

## 2) “I/O-bound” signifie typiquement…

A. Le programme est limité par les entrées/sorties (réseau, DB, fichiers)  
B. Le programme est limité par le CPU (calcul pur)  
C. Le programme est limité par CSS  
D. Le programme est limité par le typage

Réponse : **A**  
Explication : I/O-bound = limité par les entrées/sorties (réseau, DB, fichiers).

---

## 3) Quel énoncé est correct ?

A. TypeScript est exécuté par Node directement (les types existent au runtime)  
B. Node exécute du JavaScript ; le type-check est une étape séparée  
C. `tsc` est un serveur HTTP  
D. `pg` remplace l’event loop

Réponse : **B**  
Explication : Node exécute du JS ; le type-check est séparé (les types n’existent pas au runtime).

---

## 4) ESM correspond à…

A. `require/module.exports`  
B. `import/export`  
C. SQL  
D. Docker Compose

Réponse : **B**  
Explication : ESM = `import/export`.
