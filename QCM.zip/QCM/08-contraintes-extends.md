# QCM — 08 Contraintes : `extends`

## 1) Dans un générique, `extends` signifie…

A. Héritage de classes au runtime  
B. Contrainte sur le type (`T doit satisfaire ...`)  
C. Import ESM  
D. Lancement du code

Réponse : **B**  
Explication : c’est une contrainte (borne), pas de l’héritage runtime.

---

## 2) Pourquoi écrire `T extends { length: number }` ?

A. Pour empêcher `length` d’exister  
B. Pour autoriser l’accès à `.length` en sécurité  
C. Pour convertir une string en array  
D. Pour supprimer `undefined`

Réponse : **B**  
Explication : la contrainte garantit l’existence de `length`.

---

## 3) `byId<T extends { id: number }>(arr: T[], id: number)` garantit que…

A. `T` a toujours une propriété `id: number`  
B. `id` est une string  
C. `arr` est vide  
D. `T` hérite d’une classe `Id`

Réponse : **A**  
Explication : la contrainte impose `id: number` sur `T`.

---

## 4) Quand éviter de contraindre “par réflexe” ?

A. Quand la contrainte rend l’API trop rigide sans gain concret  
B. Quand TypeScript est en strict  
C. Quand on utilise `Record`  
D. Quand on utilise `readonly`

Réponse : **A**  
Explication : on contraint quand c’est nécessaire ; sinon l’API peut devenir inutilement rigide.

---

## 5) Pourquoi `{ mode: "dev" }` ne satisfait pas toujours `Mode = "dev" | "prod"` ?

A. Parce que `"dev"` est une string illégale  
B. Parce que la propriété est souvent élargie en `string` (widening)  
C. Parce que `Mode` n’existe pas au runtime  
D. Parce que `extends` ne marche qu’avec les nombres

Réponse : **B**  
Explication : dans un objet, `"dev"` peut être inféré comme `string`. `as const` (ou une annotation) conserve le littéral `"dev"`.
