# QCM — 02 Types & inférence

## 1) Que fait l’inférence de type ?

A. Elle force à écrire tous les types à la main  
B. Elle déduit automatiquement les types à partir des valeurs  
C. Elle exécute le code pour vérifier les types  
D. Elle remplace `tsconfig.json`

Réponse : **B**  
Explication : TypeScript déduit souvent le type, ce qui évite des annotations redondantes.

---

## 2) Différence principale entre `const env = "dev"` et `let env = "dev"` ?

A. `const` infère un littéral `"dev"`, `let` élargit souvent vers `string`  
B. `let` est plus strict que `const`  
C. `const` permet de réassigner  
D. Il n’y a aucune différence de type

Réponse : **A**  
Explication : `const` conserve plus facilement les types littéraux ; `let` élargit plus souvent.

---

## 3) `as const` est particulièrement utile pour…

A. Transformer du TS en JS  
B. Figer des objets/arrays (readonly) et conserver des littéraux  
C. Remplacer `unknown`  
D. Accélérer la DB

Réponse : **B**  
Explication : `as const` fige et conserve des littéraux (configs, flags, états).

---

## 4) Quand une annotation est-elle pertinente ?

A. Toujours, même pour `const x = 1`  
B. Quand on définit un contrat (API publique, paramètres, types exportés)  
C. Uniquement dans les boucles `for`  
D. Uniquement pour les `Record`

Réponse : **B**  
Explication : on annote surtout aux frontières/contrats et on laisse inférer le code interne.

---

## 5) Que signifie `(typeof HTTP_METHODS)[number]` (avec `HTTP_METHODS` en `as const`) ?

A. Le type `number`  
B. L’union des éléments du tableau (ex: `"GET" | "POST" | ...`)  
C. Le nombre d’éléments du tableau  
D. Un objet `{ number: ... }`

Réponse : **B**  
Explication : en combinant `as const` + indexation `[number]`, on obtient l’union des valeurs possibles.
