# QCM — 05 Unions & narrowing

## 1) Une union `A | B` signifie…

A. Une intersection (A et B à la fois)  
B. Une valeur qui peut être A ou B  
C. Un type inexistant au runtime  
D. Une classe

Réponse : **B**  
Explication : une union signifie “A ou B” ; il faut souvent faire du narrowing avant usage.

---

## 2) Quel exemple est un narrowing ?

A. `value + 1`  
B. `typeof value === "string"`  
C. `value = value`  
D. `return value`

Réponse : **B**  
Explication : `typeof` (ainsi que `in`, `===`) réduit une union.

---

## 3) Pourquoi modéliser des “états impossibles” ?

A. Pour écrire plus de `if`  
B. Pour rendre certains cas impossibles par construction (moins de bugs)  
C. Pour accélérer V8  
D. Pour éviter les types littéraux

Réponse : **B**  
Explication : rendre des états impossibles réduit les bugs et simplifie le code.

---

## 4) `ApiResult<T>` est typiquement utile pour…

A. Remplacer `console.log`  
B. Modéliser succès/erreur explicitement sans “magie”  
C. Éviter `Promise`  
D. Compiler plus vite

Réponse : **B**  
Explication : `ApiResult<T>` rend succès/erreur explicites (ex: `{ ok: true } | { ok: false }`).

---

## 5) Pourquoi `as const` aide dans un résultat du type `{ ok: true } | { ok: false }` ?

A. Parce que `as const` exécute une validation runtime  
B. Parce que `ok` reste un littéral `true/false` et devient un discriminant fiable  
C. Parce que `as const` transforme une union en intersection  
D. Parce que `as const` supprime `undefined`

Réponse : **B**  
Explication : conserver `ok: true` / `ok: false` permet un narrowing simple (`if (r.ok) { ... } else { ... }`).
