# QCM — 07 Génériques (intro)

## 1) Un générique `<T>` sert principalement à…

A. Rendre le code plus long  
B. Préserver une information de type entre entrée et sortie  
C. Exécuter plus vite  
D. Remplacer `keyof`

Réponse : **B**  
Explication : un générique “transporte” l’information de type (entrée → sortie).

---

## 2) Pourquoi `first(arr: any[])` est un problème ?

A. Parce que `any[]` est plus strict que `T[]`  
B. Parce qu’on perd l’information sur le type de l’élément retourné  
C. Parce que `any` empêche `map`  
D. Parce que `any` force `null`

Réponse : **B**  
Explication : `any` supprime la sécurité et on perd l’information sur le type retourné.

---

## 3) Quel est un bon exemple de générique ?

A. `log<T>(x: T): void` (T n’est jamais utilisé ailleurs)  
B. `pair<A, B>(a: A, b: B): [A, B]`  
C. `toString<T>(x: T): string` (T n’apporte rien ici)  
D. `parse<T>(s: string): any`

Réponse : **B**  
Explication : la sortie dépend des entrées (préservation d’information).

---

## 4) “Un générique doit servir à préserver une information” veut dire que…

A. On ne doit jamais écrire de génériques  
B. Si `T` n’est pas réutilisé, il est souvent inutile  
C. Les génériques remplacent les tests  
D. Les génériques existent au runtime

Réponse : **B**  
Explication : si `T` n’apporte rien, `unknown` ou un type concret est souvent plus clair.
