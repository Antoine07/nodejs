# QCM — 04 Objets & structures

## 1) Une propriété optionnelle `email?: string` implique…

A. `email` est toujours présent  
B. `email` peut être absent → `string | undefined`  
C. `email` devient `any`  
D. `email` devient `never`

Réponse : **B**  
Explication : il faut gérer l’absence (`if`, `??`, `?.`).

---

## 2) `readonly` sert à…

A. Rendre un champ obligatoire  
B. Empêcher l’affectation (mutation) sur une propriété  
C. Convertir une string en number  
D. Faire du runtime validation

Réponse : **B**  
Explication : `readonly` empêche l’affectation et évite des mutations involontaires.

---

## 3) `Record<K, V>` correspond à…

A. Un tableau typé  
B. Un dictionnaire : clés `K` → valeurs `V`  
C. Un type réservé à PostgreSQL  
D. Un alias de `unknown`

Réponse : **B**  
Explication : c’est un dictionnaire typé (ex: `Record<string, number>`).

---

## 4) Un DTO est…

A. Un modèle métier avec des règles  
B. Un objet de transport entre couches (API ↔ app ↔ DB)  
C. Une dépendance npm  
D. Une méthode de `node:http`

Réponse : **B**  
Explication : un DTO transporte des données entre couches et est souvent séparé du Domain.
