# QCM — 12 Node.js : connexion DB (PostgreSQL + `pg`)

## 1) Pourquoi utiliser un `pg.Pool` ?

A. Pour ouvrir une connexion différente à chaque requête HTTP  
B. Pour réutiliser des connexions et gérer la concurrence proprement  
C. Pour remplacer Docker  
D. Pour faire du type-check

Réponse : **B**  
Explication : un pool réutilise des connexions et gère la concurrence.

---

## 2) Une requête SQL paramétrée sert à…

A. Accélérer toujours les requêtes  
B. Éviter les injections SQL en séparant SQL et valeurs  
C. Remplacer `tsc`  
D. Forcer `unknown` en `any`

Réponse : **B**  
Explication : les placeholders (`$1`) évitent l’injection SQL.

---

## 3) Pourquoi isoler la DB dans un repository ?

A. Pour mélanger HTTP et SQL au même endroit  
B. Pour séparer responsabilités : le serveur appelle une API TypeScript au lieu d’écrire du SQL  
C. Pour éviter d’utiliser TypeScript  
D. Pour rendre le code non testable

Réponse : **B**  
Explication : le repository isole SQL/DB et simplifie le serveur (meilleure maintenabilité).

---

## 4) Les variables d’environnement (`process.env`) doivent être considérées comme…

A. Toujours présentes et bien formées  
B. Une frontière : strings, potentiellement manquantes → parsing/validation  
C. Une base de données  
D. Des types TypeScript

Réponse : **B**  
Explication : c’est une frontière ; il faut parser/valider et échouer clairement si la config est incomplète.
