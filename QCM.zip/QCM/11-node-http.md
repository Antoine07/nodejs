# QCM — 11 Node.js : `node:http`

## 1) Un endpoint HTTP est défini par…

A. Uniquement le port du serveur  
B. Une méthode + un chemin (ex: `GET /movies`)  
C. Un fichier `tsconfig.json`  
D. Un volume Docker

Réponse : **B**  
Explication : un endpoint = méthode + chemin (et parfois query/body).

---

## 2) À quoi sert `Content-Type: application/json` ?

A. À indiquer que la réponse est du JSON  
B. À chiffrer les mots de passe  
C. À compiler TypeScript  
D. À exécuter SQL

Réponse : **A**  
Explication : cela indique au client comment interpréter le body.

---

## 3) Quel verbe est le plus adapté pour récupérer une liste ?

A. `GET`  
B. `POST`  
C. `DELETE`  
D. `PATCH`

Réponse : **A**  
Explication : `GET` sert à lire/consulter une ressource.

---

## 4) Pourquoi un `POST` demande souvent plus de travail qu’un `GET` ?

A. Parce qu’il n’existe pas en HTTP  
B. Parce qu’il faut parser un body et valider les entrées  
C. Parce que `POST` ne peut pas renvoyer JSON  
D. Parce que `POST` ne peut pas renvoyer de status code

Réponse : **B**  
Explication : il faut parser le body, gérer des limites, et valider les entrées.
