# QCM — 00 Contexte de démarrage (Docker + starter)

## 1) Pourquoi lancer `dev` ET `typecheck` en parallèle ?

A. Parce que `dev` exécute le code et `typecheck` vérifie les types en continu  
B. Parce que `typecheck` lance aussi le serveur HTTP  
C. Parce que `dev` compile TypeScript en JavaScript de production  
D. Parce que `typecheck` remplace les tests

Réponse : **A**  
Explication : `dev` sert au **runtime** (exécution) et `typecheck` au **type-check** (analyse statique).

---

## 2) Que fait `docker compose down -v` ?

A. Arrête les services et supprime aussi les volumes du projet  
B. Supprime toutes les images Docker de la machine  
C. Redémarre les services sans rebuild  
D. Supprime uniquement les conteneurs, mais garde les volumes

Réponse : **A**  
Explication : le `-v` supprime les volumes, donc les données persistées (ex: base de données).

---

## 3) À quoi sert un shell dans le conteneur (ex: `docker exec -it node-ts sh`) ?

A. À exécuter des commandes dans l’environnement du conteneur  
B. À ouvrir VS Code dans Docker automatiquement  
C. À compiler TypeScript côté navigateur  
D. À se connecter à PostgreSQL sans mot de passe

Réponse : **A**  
Explication : cela permet de diagnostiquer et d’exécuter des commandes dans l’environnement du conteneur.

---

## 4) Quelle affirmation est correcte ?

A. TypeScript protège uniquement si le type-check est exécuté (local/CI)  
B. TypeScript empêche toutes les erreurs runtime  
C. Un code qui “tourne” est forcément bien typé  
D. `tsx` remplace `tsc` dans tous les cas

Réponse : **A**  
Explication : sans type-check dans le workflow, la protection TypeScript est perdue.
