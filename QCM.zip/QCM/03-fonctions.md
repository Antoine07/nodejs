# QCM — 03 Fonctions

## 1) Le “contrat” d’une fonction correspond à…

A. Son indentation  
B. Ses entrées (paramètres) et sa sortie (retour)  
C. Son nom de fichier  
D. Son temps d’exécution

Réponse : **B**  
Explication : une fonction est un contrat : types des paramètres + type de retour.

---

## 2) Que signifie `name?: string` ?

A. `name` est obligatoirement une string  
B. `name` est `string | undefined` (paramètre optionnel)  
C. `name` est `string | null`  
D. `name` est un générique

Réponse : **B**  
Explication : `?` signifie “peut être absent” → `string | undefined`.

---

## 3) Pourquoi préférer un objet d’options ?

A. Pour rendre l’ordre des paramètres moins important et éviter les signatures fragiles  
B. Pour supprimer le besoin de types  
C. Pour exécuter plus vite  
D. Pour éviter les callbacks

Réponse : **A**  
Explication : les options rendent l’API plus lisible et évolutive.

---

## 4) Typage d’un callback : avantage principal ?

A. Réduit la taille du bundle  
B. Donne l’autocomplétion à l’appelant et évite des erreurs d’usage  
C. Empêche toutes les erreurs runtime  
D. Remplace les tests

Réponse : **B**  
Explication : le callback typé documente l’API, donne l’autocomplétion et sécurise l’usage.

---

## 5) Pourquoi écrire `return [n, null] as const` dans une fonction ?

A. Pour exécuter plus vite au runtime  
B. Pour conserver un **tuple** (et éviter d’obtenir `(number | null)[]`)  
C. Pour convertir automatiquement en JSON  
D. Pour remplacer une union `A | B`

Réponse : **B**  
Explication : `as const` fige le tableau en tuple readonly, ce qui rend le contrat de retour plus précis.
