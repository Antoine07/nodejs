# QCM — Glossaire (vocabulaire du cours)

## 1) Que signifie “runtime” ?

A. Le moment où le programme s’exécute réellement  
B. Une option de `tsconfig.json`  
C. Un type TypeScript utilisé pour parser du JSON  
D. Un format de base de données

Réponse : **A**  
Explication : le runtime correspond à l’exécution réelle du programme (Node/JS).

---

## 2) “Analyse statique” (TypeScript) signifie…

A. Analyse du code sans l’exécuter  
B. Exécution du code dans un conteneur Docker  
C. Validation automatique des données API au runtime  
D. Optimisation V8

Réponse : **A**  
Explication : TypeScript vérifie les types avant l’exécution.

---

## 3) La différence la plus importante entre `any` et `unknown` est que…

A. `any` est plus strict que `unknown`  
B. `unknown` oblige à vérifier avant d’utiliser, `any` non  
C. `unknown` existe au runtime, `any` non  
D. `any` empêche les erreurs de compilation

Réponse : **B**  
Explication : `unknown` impose du narrowing/validation avant usage ; `any` désactive la sécurité.

---

## 4) Un “type guard” est…

A. Un test unitaires écrit en Jest  
B. Une fonction qui valide au runtime et informe TypeScript du type  
C. Un outil Docker pour vérifier le réseau  
D. Une règle SQL

Réponse : **B**  
Explication : un guard a typiquement une signature `value is X`.

---

## 5) “Union discriminée” signifie…

A. Une union de types primitifs uniquement  
B. Une union d’objets avec un champ “tag” commun (ex: `type`, `state`)  
C. Une intersection (`A & B`)  
D. Un tableau de littéraux

Réponse : **B**  
Explication : le tag permet un `switch` lisible et (souvent) exhaustif.

---

## 6) Le type `never` est principalement utile pour…

A. Stocker des données PostgreSQL  
B. Forcer l’exhaustivité (cas impossible) dans un `switch`  
C. Remplacer `unknown`  
D. Déclarer une variable optionnelle

Réponse : **B**  
Explication : `never` sert à représenter un cas impossible et à détecter les oublis de branches.

---

## 7) Un DTO (Data Transfer Object) est…

A. Un objet de transport entre couches (API ↔ app ↔ DB) sans logique métier  
B. Une classe qui contient toute la logique métier  
C. Un type réservé à `node:http`  
D. Une commande Docker Compose

Réponse : **A**  
Explication : un DTO représente des données “brutes” d’échange, souvent séparées du Domain.

---

## 8) Le pattern “repository” sert à…

A. Mettre du SQL directement dans le serveur HTTP  
B. Encapsuler l’accès aux données (DB) derrière une API TypeScript  
C. Remplacer PostgreSQL  
D. Remplacer `tsc`

Réponse : **B**  
Explication : le repository sépare HTTP/Domain de la persistance (SQL).

---

## 9) Une requête SQL “paramétrée” sert surtout à…

A. Éviter les injections SQL en séparant requête et valeurs  
B. Compresser la réponse JSON  
C. Remplacer les index DB  
D. Exécuter des migrations automatiquement

Réponse : **A**  
Explication : on utilise des placeholders (`$1`, `$2`, …) + un tableau de valeurs.

---

## 10) Un `pg.Pool` sert à…

A. Ouvrir une nouvelle connexion DB à chaque requête, sans réutilisation  
B. Réutiliser des connexions DB et gérer la concurrence  
C. Convertir TypeScript en JavaScript  
D. Router des URLs HTTP

Réponse : **B**  
Explication : le pool est la manière standard de gérer des connexions Postgres côté serveur.

---

## 11) “ESM” correspond à…

A. `require/module.exports`  
B. `import/export`  
C. `docker exec`  
D. `select/insert/update/delete`

Réponse : **B**  
Explication : ESM = modules modernes JavaScript.

---

## 12) “Frontière du système” désigne…

A. La limite entre deux fichiers `.ts`  
B. L’endroit où des données externes entrent (HTTP, DB, env, JSON, fichiers)  
C. Une règle de typage pour `Record`  
D. Une fonctionnalité de `tsx`

Réponse : **B**  
Explication : aux frontières, il faut souvent parsing/validation (les types seuls ne suffisent pas).

